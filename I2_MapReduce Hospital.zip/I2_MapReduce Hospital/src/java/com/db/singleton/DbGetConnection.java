/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.db.singleton;

import com.mongodb.DB;
import com.mongodb.MongoClient;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Varun
 */
public class DbGetConnection {
    public static DB db_i2mapreduce(){
        MongoClient client = null;
        DB db = null;
        try {
           client = new MongoClient("localhost",27017);
           db = client.getDB("i2_mapreduce");
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        }
        return  db;
    }
}
