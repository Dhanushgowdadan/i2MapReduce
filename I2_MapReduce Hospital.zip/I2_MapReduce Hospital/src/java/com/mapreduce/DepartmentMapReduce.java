/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mapreduce;

import com.db.singleton.DbGetConnection;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MapReduceCommand;
import com.mongodb.MapReduceOutput;
import javax.xml.ws.Response;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Varun
 */
public class DepartmentMapReduce {

    DB db;
    
    public DepartmentMapReduce() {
        db = DbGetConnection.db_i2mapreduce();
    }
    
    public JSONArray department() {
        DBCollection collection = db.getCollection("session");
        String map = "function() {"
                + "if(this.department){"
                + "emit(this.department,1);"
                + "}"
                + "}";
        String reduce = "function(key,values) {"
                + "var sum = 0;var d;"
                + "values.forEach(function(doc){"
                + "sum +=1;  "
                + "});"
                + "return {count:sum};}";
        MapReduceCommand command = new MapReduceCommand(collection, map, reduce, null, MapReduceCommand.OutputType.INLINE, null);
        MapReduceOutput output = collection.mapReduce(command);
        JSONArray arr = new JSONArray();
        for (DBObject o : output.results()) {
            JSONObject jSONObject = new JSONObject();
            
            if (o.get("value") instanceof DBObject) {
//                     System.out.println(o.get("value"));
//                     String values = (String) o.get("value");
//                     DBObject count = (BasicDBObject) o.get("count");
                jSONObject.put("label", o.get("_id"));
                jSONObject.put("value", ((DBObject) o.get("value")).get("count"));
            } else {
                jSONObject.put("label", o.get("_id"));
                jSONObject.put("value", o.get("value"));
            }
            arr.put(jSONObject);
        }
        JSONObject printObj = new JSONObject();
        printObj.put("content", arr);
        System.out.println(printObj);
        return arr;
    }

    public static void main(String[] args) {
        new DepartmentMapReduce().department();
    }
}
