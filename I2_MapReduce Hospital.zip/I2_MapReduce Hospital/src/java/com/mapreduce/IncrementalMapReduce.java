/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mapreduce;

import com.db.singleton.DbGetConnection;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MapReduceCommand;
import com.mongodb.MapReduceOutput;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.bson.types.ObjectId;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author Varun
 */
public class IncrementalMapReduce {

    DB db = DbGetConnection.db_i2mapreduce();

    DBCollection session = db.getCollection("session");
    DBCollection hospital = db.getCollection("hospitals");
    DBCollection hospitalUsage = db.getCollection("hospital_usage");

    public IncrementalMapReduce() {
        hospitalUsage.drop();
        String map = "function() {"
                + "if(this.hospitalid){"
                + "emit(this.hospitalid,1);"
                + "}"
                + "}";
        String reduce = "function(key,values) {"
                + "var sum = 0;var d;"
                + "values.forEach(function(doc){"
                + "sum +=1;  "
                + "});"
                + "return {count:sum};}";
        String finalize = "function(key,reducedValue){"+
                "if (reducedValue.count > 0)"+
                " reducedValue.avg_time = reducedValue.total_time / reducedValue.count;"+
                "return reducedValue;"+
                "};";
        MapReduceCommand command = new MapReduceCommand(session, map, reduce, null, MapReduceCommand.OutputType.INLINE, null);
        MapReduceOutput output = session.mapReduce(command);
        JSONArray arr = new JSONArray();
        for (DBObject o : output.results()) {
            BasicDBObject bdo = (BasicDBObject) o;
            DBCursor cursor = hospital.find(new BasicDBObject("_id", new ObjectId(bdo.getString("_id"))));
            while (cursor.hasNext()) {
                BasicDBObject hospitalRow = (BasicDBObject) cursor.next();
                o.put("hospital", hospitalRow.getString("h_name"));
            }
            hospitalUsage.insert(o);

        }

    }
    
    public JSONArray findUsage(){
        String map = "function() {"
                + "if(this.hospitalid){"
                + "emit(this.hospitalid,1);"
                + "}"
                + "}";
        String reduce = "function(key,values) {"
                + "var sum = 0;var d;"
                + "values.forEach(function(doc){"
                + "sum +=1;  "
                + "});"
                + "return {count:sum};}";
        MapReduceCommand command = new MapReduceCommand(session, map, reduce, null, MapReduceCommand.OutputType.INLINE, null);
        MapReduceOutput output = session.mapReduce(command);
        JSONArray arr = new JSONArray();
        for (DBObject o : output.results()) {
            JSONObject jSONObject = new JSONObject();
            BasicDBObject bdo = (BasicDBObject) o;
            DBCursor cursor = hospital.find(new BasicDBObject("_id", new ObjectId(bdo.getString("_id"))));
            while (cursor.hasNext()) {
                BasicDBObject hospitalRow = (BasicDBObject) cursor.next();
                o.put("hospital", hospitalRow.getString("h_name"));
            }
            jSONObject.put("label",o.get("hospital"));
            jSONObject.put("value",((DBObject) o.get("value")).get("count"));
            arr.put(jSONObject);
        }
        return  arr;
    } 
    
    public static void main(String[] args) {
       IncrementalMapReduce imr = new IncrementalMapReduce();
        System.out.println(imr.findUsage());
    }

}
