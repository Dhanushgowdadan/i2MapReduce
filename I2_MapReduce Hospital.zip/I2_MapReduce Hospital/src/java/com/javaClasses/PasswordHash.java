/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.javaClasses;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Varun
 */
public class PasswordHash {
    public static StringBuffer md5Hash(String password){
        StringBuffer sb = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            byte byteData[] = md.digest();
            sb = new StringBuffer();
            for(int i=0;i<byteData.length;i++){
                sb.append(Integer.toString((byteData[i] & 0xff) + 0xff,16).substring(1));
            }
            
        } catch (NoSuchAlgorithmException ex) {
            ex.printStackTrace();
        }
        return sb;
    }
}
