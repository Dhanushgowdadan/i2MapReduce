/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.addingDatabases;

import com.javaClasses.PasswordHash;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Varun
 */
public class MainCollection {
    public static void main(String[] args) {
        try {
            StringBuffer pass = PasswordHash.md5Hash("admin");;
            MongoClient mongoClient = new MongoClient("localhost",27017);
            DB db = mongoClient.getDB("i2_mapreduce");
            System.out.println("Connect to databse successfully");
            boolean auth = db.authenticate("admin","admin".toCharArray());
            System.out.println(auth);
             BasicDBObject bdbo = new BasicDBObject();
             bdbo.put("name", "admin");
             bdbo.put("password", pass.toString());
             DBCollection dBCollection = db.getCollection("admin");
             dBCollection.insert(bdbo);
            System.out.println("Collection created successfully");
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        }
    }
}
