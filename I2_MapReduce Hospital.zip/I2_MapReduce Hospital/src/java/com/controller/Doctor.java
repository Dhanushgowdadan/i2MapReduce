/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.db.singleton.DbGetConnection;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Varun
 */
@WebServlet(name = "Doctor", urlPatterns = {"/Doctor"})
public class Doctor extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            DB db = DbGetConnection.db_i2mapreduce();
            
            if(request.getParameter("login") != null){
                String name = "";
                String id = "",email = "",department="";
                System.out.println("login");
                boolean auth = false;
                String userName = request.getParameter("username");
                String userpassword = request.getParameter("password");
                String hospital = request.getParameter("hospital");
                DBCollection hospitals = db.getCollection("doctors");
                BasicDBObject obj = new BasicDBObject();
                System.out.println(userName);
                obj.put("uname", userName);
                obj.put("password", userpassword);
                obj.put("hospitalid", hospital);
    
                
                DBCursor cursor = hospitals.find(obj);
                while(cursor.hasNext()){
                    BasicDBObject dbdata = (BasicDBObject) cursor.next();
                    id = dbdata.getString("_id");
                    name = dbdata.getString("uname");
                    email = dbdata.getString("email");
                    department = dbdata.getString("department");
                    auth = true;
                }
                //Login authenticate
                if(auth){
                    HttpSession session = request.getSession(true);
                    session.setAttribute("id", id);
                    session.setAttribute("name", name);
                    session.setAttribute("email", email);
                    
                    DBCollection sessionColl = db.getCollection("session");
                    
                    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                    Date date = new Date();
                    BasicDBObject sessionObj = new BasicDBObject();
                    sessionObj.put("uname", userName);
                    sessionObj.put("hospitalid", hospital);
                    sessionObj.put("email", email);
                    sessionObj.put("department", department);
                    sessionObj.put("date_time", dateFormat.format(date));
                    
                    sessionColl.insert(sessionObj);
                    
                    response.sendRedirect("doctor/viewPatient.jsp");
                    
                    
                }
                else{
                    out.print("<script> alert('Invalid User Password'); window.history.back(); </script>");
                }
                
            }
            
            if(request.getParameter("addpresc") != null){
                String patientType = request.getParameter("patient-type");
                String patientName = request.getParameter("patient-name");
                String pre = request.getParameter("prescription");
                HttpSession hs = request.getSession(false);
                String sessi = hs.getAttribute("id").toString();
                
                DBCollection presc = db.getCollection("prescription");
                BasicDBObject bdbo = new BasicDBObject();
                bdbo.put("patientType", patientType);
                bdbo.put("patientName", patientName);
                bdbo.put("prescription", pre);
                bdbo.put("doctorId", sessi);
                presc.insert(bdbo);
                out.print("<script> alert('Prescription added successfull'); window.history.back(); </script>");
            }
            
            if(request.getParameter("addtesting") != null){
                HttpSession hs = request.getSession(false);
                String sessi = hs.getAttribute("id").toString();
                
                String patientType = request.getParameter("patient-type");
                String patient = request.getParameter("patient-name");
                String testing = request.getParameter("testing");
                DBCollection labTest = db.getCollection("labtesting");
                BasicDBObject bdbo = new BasicDBObject();
                bdbo.put("patientType", patientType);
                bdbo.put("patientName", patient);
                bdbo.put("labtest", testing);
                bdbo.put("doctorId", sessi);
                labTest.insert(bdbo);
            }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
