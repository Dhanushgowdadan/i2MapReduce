/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import static com.db.singleton.DbGetConnection.db_i2mapreduce;
import com.javaClasses.PasswordHash;
import static com.javaClasses.PasswordHash.md5Hash;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.ReadPreference;
import com.mongodb.WriteConcern;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.bson.types.ObjectId;

/**
 *
 * @author Varun
 */
@WebServlet(name = "hostipalRegister", urlPatterns = {"/hostipalRegister"})
public class hostipalRegister extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            boolean twinemail = false;
            DB db = db_i2mapreduce();
            
            
            if(request.getParameter("register")!=null){
                System.out.println("registration");
                String hospitalName = request.getParameter("username");
                String email = request.getParameter("email");
                String phone = request.getParameter("phone");
                StringBuffer password = md5Hash(request.getParameter("password"));
                String address = request.getParameter("address");
                DBCollection hospital = db.getCollection("hospitals");
                BasicDBObject query = new BasicDBObject();
                List <BasicDBObject> obj = new ArrayList<BasicDBObject>();
//                obj.add(new BasicDBObject("email",email));
//                obj.add(new BasicDBObject("active",new BasicDBObject("$gt",0)));
                query.put("email", email);
                
                DBCursor cursor = hospital.find(query);
                
                while(cursor.hasNext()){
                    cursor.next();
                    twinemail = true;
                }
            
                if(twinemail){
                    System.out.println("test");
                    out.print("<script> alert('Email Already Exists'); window.history.back(); </script>");
                }
                
                else{
                    BasicDBObject user = new BasicDBObject();
                    user.put("h_name",hospitalName);
                    user.put("email",email);
                    user.put("phone",phone);
                    user.put("password",password.toString());
                    user.put("address",address);
                    user.put("active",0);
                    hospital.insert(user);
                    out.print("<script> alert('Register successful'); window.history.back(); </script>");
                }
            }
            
            if(request.getParameter("login") != null){
                String name = "";
                String id = "",email = "";
                System.out.println("login");
                boolean auth = false;
                String userName = request.getParameter("username");
                StringBuffer userpassword = md5Hash(request.getParameter("password"));
                DBCollection hospitals = db.getCollection("hospitals");
                BasicDBObject obj = new BasicDBObject();
                System.out.println(userName);
                obj.put("email", userName);
                obj.put("password", userpassword.toString());
                obj.put("active", new BasicDBObject("$gt",0));
                
                DBCursor cursor = hospitals.find(obj);
                while(cursor.hasNext()){
                    BasicDBObject dbdata = (BasicDBObject) cursor.next();
                    id = dbdata.getString("_id");
                    name = dbdata.getString("name");
                    email = dbdata.getString("email");
                    auth = true;
                }
                //Login authenticate
                if(auth){
                    HttpSession session = request.getSession(true);
                    session.setAttribute("id", id);
                    session.setAttribute("name", name);
                    session.setAttribute("email", email);
                    response.sendRedirect("hospital/pages/staff.jsp");
                }
                else{
                    out.print("<script> alert('Invalid User Password'); window.history.back(); </script>");
                }
                
            }
            
            if(request.getParameter("addDepartment") !=null){
                System.out.println("department");
                String dept = request.getParameter("department");
                String desc = request.getParameter("desc");
                boolean successInsert = false;
                DBCollection department = db.getCollection("department");
                BasicDBObject bdbo = new BasicDBObject();
                bdbo.put("department", dept);
                bdbo.put("description", desc);
                department.insert(bdbo);
                DBCursor cursor = department.find(bdbo);
                while (cursor.hasNext()) {
                    cursor.next();
                    successInsert = true;
                }
                if(successInsert){
                    out.print("<script> alert('Department Added Successfully'); window.location.href = 'hospital/pages/department.jsp'; </script>");
                }
                else{
                    out.print("<script> alert('Error Adding Department'); window.location.back(); </script>");
                }
            }
            
            if(request.getParameter("addStaff") !=null){
                String department = request.getParameter("department");
                String uname = request.getParameter("username");
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                String phone = request.getParameter("phone");
                String fname = request.getParameter("fname");
                String lname = request.getParameter("lname");
                DBCollection staff = db.getCollection("staff");
                String hospitalName = request.getSession(false).getAttribute("email").toString();
                BasicDBObject bObject = new BasicDBObject();
                bObject.put("department", department);
                bObject.put("uname", uname);
                bObject.put("email", email);
                bObject.put("password", password);
                bObject.put("phone", phone);
                bObject.put("fname", fname);
                bObject.put("lname", lname);
                String session = request.getSession(false).getAttribute("id").toString();
                bObject.put("hospital", session);
                bObject.put("hospitalname", hospitalName);
                staff.insert(bObject,WriteConcern.SAFE);
                out.print("<script> alert('Staff Added Successfully'); window.location.href = 'hospital/pages/staff.jsp'; </script>");
            }
            
            if(request.getParameter("delstaff") != null){
                DBCollection staff = db.getCollection("staff");
                BasicDBObject bObject = new BasicDBObject();
                bObject.put("_id", new ObjectId(request.getParameter("delstaff")));
                staff.remove(bObject);
                DBObject dbObj = staff.findOne(bObject);
                if(dbObj==null){
                    out.print("<script> window.location.href = 'hospital/pages/staff.jsp'; </script>");
                }
                else{
                    out.print("<script> alert(''Error Deleting Staff); window.location.href = 'hospital/pages/staff.jsp'; </script>");
                }
            }
            
            if(request.getParameter("addDoctor") !=null){
                String department = request.getParameter("department");
                String uname = request.getParameter("username");
                String email = request.getParameter("email");
                String password = request.getParameter("password");
                String phone = request.getParameter("phone");
                String fname = request.getParameter("fname");
                String lname = request.getParameter("lname");
                String hospitalId = request.getSession(false).getAttribute("id").toString();
                String hospitalName = request.getSession(false).getAttribute("email").toString();
                DBCollection staff = db.getCollection("doctors");
                BasicDBObject bObject = new BasicDBObject();
                bObject.put("department", department);
                bObject.put("uname", uname);
                bObject.put("email", email);
                bObject.put("password", password);
                bObject.put("phone", phone);
                bObject.put("fname", fname);
                bObject.put("lname", lname);
                
                bObject.put("hospitalid", hospitalId);
                bObject.put("hospitalname", hospitalName);
                staff.insert(bObject,WriteConcern.SAFE);
                out.print("<script> alert('Doctor Added Successfully'); window.location.href = 'hospital/pages/doctor.jsp'; </script>");
            }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
