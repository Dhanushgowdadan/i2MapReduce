/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MapReduceCommand;
import com.mongodb.MapReduceOutput;
import com.mongodb.Mongo;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Varun
 */
public class MapReduceTest {
   
    public static void main(String[] args) {
        try {
            Mongo mongo = new Mongo("localhost",27017);
            DB db = mongo.getDB("i2_mapreduce");
            DBCollection collection = db.getCollection("session");
//            String map ="function() { "+
//                    "var category;var date;"+
//                    "if(this.hospital)"+
//                    "category='Apollo';"+
//                    "else"+
//                    "category = 'Hospital';"+
//                    "emit(category,{name:this.department,email:this.email});}";
            String map = "function() {"+
                    "if(this.department){"+
                    "emit(this.department,1);"+
                    "}"+
                    "}";
//            String map = "function () {  "+
//                    "if(this.department=='Cardiology')"+
//                    " category = 'babu'; "+
//                    "else "+
//                    " emit(category,{department:this.department,email:this.email,date:this.date_time}); "+
//                    "}";
//            String map ="function(){  "+
//                    "var keys = {department:this.department,email:this.email,date:this.date_time};"+
//                    "if(this.department=='Cardiology') {"+
//                    "emit(keys,{count:5});"+
//                    " } "+
//                    "else{"+
//                    "emit(keys,{count:1});}}";
                    
            String reduce = "function(key,values) {"+
                    "var sum = 0;var d;"+
                    "values.forEach(function(doc){"+
                    "sum +=1;  "+
                    "});"+
                    "return {count:sum};}";
            MapReduceCommand command = new MapReduceCommand(collection, map, reduce, null, MapReduceCommand.OutputType.INLINE, null);
            MapReduceOutput output = collection.mapReduce(command);
            for(DBObject o : output.results()){
                System.out.println(o.toString());
            }
            
        } catch (UnknownHostException ex) {
            ex.printStackTrace();
        }
    }
 
}
