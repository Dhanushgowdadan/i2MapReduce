/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import static com.db.singleton.DbGetConnection.db_i2mapreduce;
import static com.javaClasses.PasswordHash.md5Hash;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.bson.types.ObjectId;

/**
 *
 * @author Varun
 */
@WebServlet(name = "admin", urlPatterns = {"/admin"})
public class admin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            DB db = db_i2mapreduce();
            
            if(request.getParameter("login") != null){
                String name = "";
                String id = "",email = "";
                System.out.println("login");
                boolean auth = false;
                String userName = request.getParameter("username");
                StringBuffer userpassword = md5Hash(request.getParameter("password"));
                DBCollection admin = db.getCollection("admin");
                BasicDBObject obj = new BasicDBObject();
                System.out.println(userName);
                obj.put("name", userName);
                obj.put("password", userpassword.toString());
                
                DBCursor cursor = admin.find(obj);
                while(cursor.hasNext()){
                    BasicDBObject dbdata = (BasicDBObject) cursor.next();
                    id = dbdata.getString("_id");
                    name = dbdata.getString("name");
                    email = dbdata.getString("email");
                    auth = true;
                }
                //Login authenticate
                if(auth){
                    HttpSession session = request.getSession(true);
                    session.setAttribute("id", id);
                    session.setAttribute("name", name);
                    session.setAttribute("email", email);
                    response.sendRedirect("admin/adminHome.jsp");
                }
                else{
                    out.print("<script> alert('Invalid User Password'); window.history.back(); </script>");
                }
                
            }
            //accept
            
            if(request.getParameter("accept") !=null ){
                DBCollection hospital = db.getCollection("hospitals");
                BasicDBObject newText = new  BasicDBObject();
                newText.append("$set", new BasicDBObject("active",1));
                BasicDBObject search = new BasicDBObject();
                search.put("_id", new ObjectId(request.getParameter("accept")));
                hospital.update(search, newText);
            }
            
            //reject
            if(request.getParameter("reject") !=null ){
                System.out.println(request.getParameter("reject"));
                DBCollection hospital = db.getCollection("hospitals");
                BasicDBObject newText = new  BasicDBObject();
                newText.append("$set", new BasicDBObject("active",0));
                BasicDBObject search = new BasicDBObject();
                search.put("_id", new ObjectId(request.getParameter("reject")));
                hospital.update(search, newText);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
