/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.db.singleton.DbGetConnection;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.bson.types.ObjectId;

/**
 *
 * @author Varun
 */
@WebServlet(name = "Staff", urlPatterns = {"/Staff"})
public class Staff extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */

            DB db = DbGetConnection.db_i2mapreduce();

            if (request.getParameter("login") != null) {
                String category = request.getParameter("category");
                if (category.equals("Receptionist")) {
                    String hospital = request.getParameter("hospital");
                    String username = request.getParameter("username");
                    String password = request.getParameter("password");
                    String staffId = "", department = "", staffHospital = "";

                    DBCollection collection = db.getCollection("staff");
                    boolean loginAuth = false;
                    BasicDBObject object = new BasicDBObject();
                    object.put("hospital", hospital);
                    object.put("department", category);
                    object.put("uname", username);
                    object.put("password", password);

                    DBCursor cursor = collection.find(object);
                    while (cursor.hasNext()) {
                        BasicDBObject row = (BasicDBObject) cursor.next();
                        staffId = row.getString("_id");
                        department = row.getString("department");
                        department = row.getString("department");
                        loginAuth = true;
                    }

                    if (loginAuth) {
                        HttpSession session = request.getSession(true);
                        session.setAttribute("staffid", staffId);
                        session.setAttribute("department", department);
                        session.setAttribute("hospital", staffHospital);
                        out.println("<script> alert('Login Successfull'); window.location.href = 'staff/pages/OutPatient.jsp'; </script>");
                    } else {
                        out.println("<script> alert('Login Failed'); window.history.back(); </script>");
                    }
                }
                
                if (category.equals("Lab Technician")) {
                    String hospital = request.getParameter("hospital");
                    String username = request.getParameter("username");
                    String password = request.getParameter("password");
                    String staffId = "", department = "", staffHospital = "";

                    DBCollection collection = db.getCollection("staff");
                    boolean loginAuth = false;
                    BasicDBObject object = new BasicDBObject();
                    object.put("hospital", hospital);
                    object.put("department", category);
                    object.put("uname", username);
                    object.put("password", password);

                    DBCursor cursor = collection.find(object);
                    while (cursor.hasNext()) {
                        BasicDBObject row = (BasicDBObject) cursor.next();
                        staffId = row.getString("_id");
                        department = row.getString("department");
                        department = row.getString("department");
                        loginAuth = true;
                    }

                    if (loginAuth) {
                        HttpSession session = request.getSession(true);
                        session.setAttribute("staffid", staffId);
                        session.setAttribute("department", department);
                        session.setAttribute("hospital", staffHospital);
                        out.println("<script> alert('Login Successfull'); window.location.href = 'labtechnician/viewtesting.jsp'; </script>");
                    } else {
                        out.println("<script> alert('Login Failed'); window.history.back(); </script>");
                    }
                }
                
                
            }

            if (request.getParameter("addop") != null) {
                String pname = "";
                String phone = "";
                String age = "";
                String email = "";
                String dept = "";
                String gender = "";
                String doctor = "";
                String blood = "";
                pname = request.getParameter("pname");
                phone = request.getParameter("phone");
                age = request.getParameter("age");
                email = request.getParameter("email");
                dept = request.getParameter("department");
                gender = request.getParameter("gender");
                doctor = request.getParameter("doctor");
                blood = request.getParameter("blood");
                DBCollection outpatient = db.getCollection("out_patient");
                BasicDBObject bdbo = new BasicDBObject();
                bdbo.put("patient", pname);
                bdbo.put("phone", phone);
                bdbo.put("age", age);
                bdbo.put("email", email);
                bdbo.put("dept", dept);
                bdbo.put("gender", gender);
                bdbo.put("doctor", doctor);
                bdbo.put("blood", blood);
                outpatient.insert(bdbo);
                out.print("<script> alert('Successfully Added'); window.history.back(); </script>");

            }

            if (request.getParameter("addin") != null) {
                String pname = "";
                String phone = "";
                String age = "";
                String email = "";
                String dept = "";
                String gender = "";
                String doctor = "";
                String blood = "";
                boolean checkExists = false;
                int ward, bed;
                pname = request.getParameter("pname");
                phone = request.getParameter("phone");
                age = request.getParameter("age");
                email = request.getParameter("email");
                dept = request.getParameter("department");
                gender = request.getParameter("gender");
                doctor = request.getParameter("doctor");
                blood = request.getParameter("blood");
                ward = Integer.parseInt(request.getParameter("ward"));
                bed = Integer.parseInt(request.getParameter("bed"));
                DBCollection inpatient = db.getCollection("in_patient");
                BasicDBObject bdbo = new BasicDBObject();
                bdbo.put("patient", pname);
                bdbo.put("phone", phone);
                bdbo.put("age", age);
                bdbo.put("email", email);
                bdbo.put("dept", dept);
                bdbo.put("gender", gender);
                bdbo.put("doctor", doctor);
                bdbo.put("blood", blood);
                bdbo.put("ward", ward);
                bdbo.put("bed", bed);
                BasicDBObject CheckInWard = new BasicDBObject();
                CheckInWard.put("ward", ward);
                CheckInWard.put("bed", bed);

                DBCursor cursor = inpatient.find(CheckInWard);
                while (cursor.hasNext()) {
                    cursor.next();
                    checkExists = true;
                }
                if (checkExists) {
                    out.print("<script> alert('Someone else in the bed'); window.history.back(); </script>");
                } else {
                    inpatient.insert(bdbo);
                    out.print("<script> alert('Successfully Added'); window.history.back(); </script>");
                }
            }

            if (request.getParameter("del-out-patient") != null) {
                DBCollection delOutPatient = db.getCollection("out_patient");
                BasicDBObject bdbo = new BasicDBObject();
                bdbo.put("_id", new ObjectId(request.getParameter("del-out-patient")));
                delOutPatient.remove(bdbo);
                out.print("<script> alert('Deleted Successfully'); window.history.back(); </script>");
            }

            if (request.getParameter("del-in-patient") != null) {
                DBCollection delOutPatient = db.getCollection("in_patient");
                BasicDBObject bdbo = new BasicDBObject();
                bdbo.put("_id", new ObjectId(request.getParameter("del-in-patient")));
                delOutPatient.remove(bdbo);
                out.print("<script> alert('Deleted Successfully'); window.history.back(); </script>");
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
